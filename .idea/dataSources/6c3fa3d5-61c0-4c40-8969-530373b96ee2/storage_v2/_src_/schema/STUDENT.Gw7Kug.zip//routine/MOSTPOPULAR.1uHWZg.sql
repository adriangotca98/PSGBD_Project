create function mostPopular(id_student studenti.id%type) 
return studenti.id%type as
    id_mostPopular studenti.id%type;
    grupa_student studenti.grupa%type;
    friends number;
    maxfriends number:=-1;
    cursor studentList is select * from studenti;
begin
    select grupa into grupa_student from studenti where id=id_student;
    for student in studentList loop
        if (student.grupa=grupa_student) then
            select count(*) into friends from prieteni where id_student1=student.id;
            if (maxfriends<friends) then id_mostPopular:=student.id;
            end if;
        end if;
    end loop;
    return id_mostPopular;
end;
/

