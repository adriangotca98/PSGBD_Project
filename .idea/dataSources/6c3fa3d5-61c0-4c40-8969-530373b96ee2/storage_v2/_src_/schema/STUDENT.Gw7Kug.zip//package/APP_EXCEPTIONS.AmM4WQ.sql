create PACKAGE app_exceptions
AS
    student_inexistent EXCEPTION;
    PRAGMA EXCEPTION_INIT (student_inexistent, -20001);
    bursa_prea_mare EXCEPTION;
    PRAGMA EXCEPTION_INIT (bursa_prea_mare, -20002);
end;
/

