create procedure sortare_studenti as
    cursor studenti1 is select * from studenti order by nume, prenume;
    popular studenti.id%type;
    media1 float;
    media2 float;
    n_ume studenti.nume%type;
    p_renume studenti.prenume%type;
    g_rupa studenti.grupa%type;
begin
    for student in studenti1 loop
        popular:=mostPopular(student.id);
        select nume, prenume, grupa into n_ume,p_renume,g_rupa from studenti where id=popular;
        dbms_output.put_line(student.nume||' '||student.prenume||' - '||student.grupa||'; '||n_ume||' '||p_renume||' - '||g_rupa);
        select avg(valoare) into media1 from note where id_student=student.id;
        select avg(valoare) into media2 from note where id_student=popular;
        if (media1>media2) then
            dbms_output.put_line(student.nume||' '||student.prenume||' are media mai mare.');
        end if;
        dbms_output.put_line(media1||' '||media2);
        if (media1<media2) then
            dbms_output.put_line(n_ume||' '||p_renume||' are media mai mare.');
        end if;
        if (media1=media2) then
            dbms_output.put_line('Mediile sunt egale.');
        end if;
    end loop;
end;
/

