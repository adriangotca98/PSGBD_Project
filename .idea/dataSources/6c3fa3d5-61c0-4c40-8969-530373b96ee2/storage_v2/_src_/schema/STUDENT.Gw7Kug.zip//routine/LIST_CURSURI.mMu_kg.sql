create function list_cursuri(profid number)
return lista_id_cursuri as
    id_cursuri lista_id_cursuri;
begin
    select id_curs bulk collect into id_cursuri from didactic where id_profesor=profid;
    return id_cursuri;
end;
/

