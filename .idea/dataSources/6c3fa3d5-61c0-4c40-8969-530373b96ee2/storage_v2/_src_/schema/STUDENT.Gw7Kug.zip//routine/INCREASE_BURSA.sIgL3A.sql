create FUNCTION increase_bursa(
    stud_id studenti.id%type)
    return VARCHAR2 as
    v_majorare_bursa INTEGER;
    v_bursa studenti.bursa%type;
    v_mesaj VARCHAR2(256);
    counter INTEGER;
BEGIN
    SELECT COUNT(*) INTO COUNTER FROM STUDENTI WHERE ID=STUD_ID;
    v_majorare_bursa := 1800;
    IF counter=0 then
        raise app_exceptions.student_inexistent;
    end if;
    SELECT bursa INTO v_bursa from studenti where id = stud_id;
    IF v_bursa is null then
        v_bursa := 0;
    end if;
    v_bursa := v_bursa + v_majorare_bursa;
    if v_bursa > 3000 then
        UPDATE studenti set bursa = 3000 where id = stud_id;
        raise app_exceptions.bursa_prea_mare;
    end if;
    UPDATE studenti set bursa = v_bursa where id = stud_id;
    v_mesaj := 'Bursa pentru studentul cu id ' || stud_id || ' a fost updatata la ' || v_bursa;
    return v_mesaj;
end increase_bursa;
/

