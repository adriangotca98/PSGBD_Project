create function nume_curs(id_curs number)
return cursuri.titlu_curs%type as
    name cursuri.titlu_curs%type;
begin
    select titlu_curs into name from cursuri where id=id_curs;
    return name;
end;
/

