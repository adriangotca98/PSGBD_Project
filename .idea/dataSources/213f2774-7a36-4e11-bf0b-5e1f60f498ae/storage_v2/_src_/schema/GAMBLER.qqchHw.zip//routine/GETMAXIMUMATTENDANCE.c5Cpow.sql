create FUNCTION getMaximumAttendance(id_echipa INT)
RETURN INT AS
    id_stadion INT;
    capacitate INT;
BEGIN
    SELECT id_stadium INTO id_stadion FROM TEAM WHERE id_echipa=id_team;
    SELECT CAPACITY INTO capacitate FROM STADIUM WHERE id_stadium=id_stadion;
    return capacitate;
END;
/

